

## Public mirror sanitization

This mirror excludes operational connection references and environment variable definitions.

Redacted values include Business Central API URLs, Power Pages portal URLs, GUID identifiers, tenant/company/environment identifiers, and possible client secret values.

Use the private Power Platform repository as the deployment source of truth. Use this repository for documentation, architecture review, and code analysis only.
