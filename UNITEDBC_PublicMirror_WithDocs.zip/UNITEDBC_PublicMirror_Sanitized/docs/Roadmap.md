# Roadmap

## Current state

The solution is now source-controlled and has a sanitized public mirror structure. Core Dataverse tables, portal assets, cloud flows, and solution metadata are present.

## Near-term priorities

1. Confirm canonical checkout flow path.
2. Review and clean up test/deleted Power Pages assets.
3. Complete storefront catalogue page against `ldw_catalogitem`.
4. Complete cart drawer/page and quantity update/remove UX.
5. Complete checkout confirmation and order confirmation UX.
6. Verify end-to-end BC customer and sales order creation.
7. Resolve email confirmation delivery.
8. Build initial public mirror README and docs index.

## Medium-term priorities

- Implement or finalize BC -> Dataverse catalogue sync.
- Implement or finalize public price and tier price sync.
- Add My Orders page using BC/order mirror data.
- Add telemetry/logging for checkout failures.
- Perform security review of table permissions and Web API field exposure.
- Prepare UAT checklist and rollback/runbook.

## Future automation

Automate public mirror synchronization with an Azure DevOps pipeline once manual sanitization rules have stabilized. The pipeline should copy allowed folders, exclude operational configuration, redact identifiers, and commit to the public mirror repository.
