# Flows

## Flow inventory

| Flow file | Trigger(s) | Top-level actions |
| --- | --- | --- |
| CheckoutProcessingFlowPowerAutomate-0299A8BE-904E-F111-BEC6-6045BDC46C25.json | When_a_row_is_added,_modified_or_deleted | Main, bcCustomerNo, CATCH, Condition_2 |
| CheckoutflowPowerAutomate-A918643D-618C-F011-B4CB-7CED8D330A7E.json | manual | List_rows_from_selected_environment, Create_record_(V3), Get_a_row_by_ID_from_selected_environment, Apply_to_each, Update_a_row_in_selected_environment, Response, Get_row_by_ID_(Contact), bcCustomerNo, Set_variable, Condition |
| CatalogueNightlyFill-DF961FCB-8526-F111-88B4-6045BDE5F52C.json | Recurrence | List_rows, Apply_to_each |


## Current flow roles

### CatalogueNightlyFill

Synchronizes or upserts BC catalogue data into native Dataverse catalogue tables. This supports the architectural decision to use native Dataverse storefront reads instead of direct BC virtual table reads from Power Pages.

### Checkout flow / Checkout Processing flow

Handles checkout orchestration. The solution currently contains both an HTTP-triggered checkout flow and a Dataverse row-triggered checkout-processing flow. The intended long-term pattern should be made explicit so the project has one canonical checkout entry point.

## Flow design rules

- Use solution-aware connection references.
- Do not hardcode environment-specific URLs in actions where an environment variable can be used.
- Keep BC as the authoritative pricing and order engine.
- Treat cart snapshot prices as UX-supporting values only.
- Record enough checkout status and error information for operational support.
