# Power Pages

## Site

- Site folder: `powerpagesites/UnitedinBC---site-p2sfr`

## Web pages

- `Access-Denied`
- `BLANK-10112025-deleted`
- `CHECKOUT`
- `CHECKOUT2`
- `Cart-Page`
- `Catalogue`
- `FORMTEST`
- `Home`
- `My-Orders`
- `Order-Confirmation`
- `PRODUCT-deleted`
- `PRODUCT2`
- `Page-Not-Found`
- `Product3-deleted`
- `Profile`
- `Search`
- `TEST-PAGE`
- `TESTNEW`
- `TESTNEWPAGE-deleted`
- `af-token`

## Web templates

- `AF-Token`
- `Breadcrumbs`
- `Default-studio-template`
- `Footer`
- `Header`
- `Languages-Dropdown`
- `Layout-2-Column-Wide-Left`
- `Page-Copy`
- `Page-Header`
- `Pages-Breadcrumb`
- `Pagination`
- `Power-Virtual-Agents`
- `Search`
- `Search-Results`

## Web files

- `Cat-PC.png`
- `Logo-sm-64.png`
- `PWAManifest.json`
- `bootstrap.min.css`
- `portalbasictheme.css`
- `theme.css`

## Web roles

- `Administrators`
- `Anonymous-Users`
- `Authenticated-Users`

## Table permissions

- `Cart-(Contact-scope)`
- `Cart-line-2`
- `Catalog-Item-(Global)`
- `Checkout-Request`
- `Contact---AppendTo-Cart`
- `Item-(BC-VT)`

## Web API site settings

- `Webapi-EnableCreateOperation`
- `Webapi-EnableDeleteOperation`
- `Webapi-EnableReadOperation`
- `Webapi-EnableUpdateOperation`
- `Webapi-UseUTCDateTime`
- `Webapi-contact-enabled`
- `Webapi-contact-fields`
- `Webapi-dyn365bc_item_v2_0-enabled`
- `Webapi-dyn365bc_item_v2_0-fields`
- `Webapi-ldw_cart-enabled`
- `Webapi-ldw_cart-fields`
- `Webapi-ldw_cartline-enabled`
- `Webapi-ldw_cartline-fields`
- `Webapi-ldw_cartline2-enabled_84b2a71c`
- `Webapi-ldw_cartline2-enabled_cd02e020`
- `Webapi-ldw_cartline2-fields_4bdcab2d`
- `Webapi-ldw_cartline2-fields_d4545cee`
- `Webapi-ldw_catalogitem-enabled`
- `Webapi-ldw_catalogitem-fields`
- `Webapi-ldw_checkoutrequest-enabled`
- `Webapi-ldw_checkoutrequest-fields`

## Notes

- `Cart Line 2` is the authoritative cart-line table. Legacy `cartline` has been removed from the working solution.
- Pages with `deleted` or test-style names should be periodically reviewed and removed from the solution when no longer needed.
- Web API table settings should be kept aligned with table permissions and the portal JavaScript entity-set names.
