# Decisions

## Active decisions

| Date | Decision | Status | Rationale |
| --- | --- | --- | --- |
| 2025-08-27 | Store cart in Dataverse rather than BC draft orders | Active | Improves portal UX and avoids using BC as an interactive cart engine. |
| 2025-08-27 | Use Power Automate / integration layer for checkout | Active | Keeps checkout orchestration outside page JavaScript. |
| 2026-03 | Use native Dataverse catalogue/pricing mirror tables for storefront reads | Active | Power Pages Web API and direct BC virtual table reads proved unreliable for storefront usage. |
| 2026-03 | Treat BC as authoritative for pricing and totals | Active | Avoids duplicating BC business logic in the portal. |
| 2026-03 | Create real BC customers for portal contacts when missing | Active | Avoids relying on a generic web customer as the normal checkout path. |
| 2026-06 | Keep private repo authoritative and public mirror sanitized | Active | Enables long-term external review without exposing operational configuration. |
| 2026-06 | Use `Cart Line 2` / `ldw_cartline2` as the authoritative cart-line table | Active | Legacy `cartline` was removed. |

## Open decisions

- Choose the canonical checkout entry point: HTTP-triggered checkout flow vs `Checkout Request` row-triggered processing flow.
- Decide whether email confirmation remains Power Pages SMTP-based or moves to Power Automate / Microsoft 365 mail.
- Decide whether public mirror synchronization remains manual or is automated via Azure DevOps pipeline.
- Decide whether test/deleted portal pages should be removed from the solution before production hardening.
