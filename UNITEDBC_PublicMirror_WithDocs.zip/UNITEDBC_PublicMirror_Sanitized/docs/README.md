# UNITEDBC Documentation

This folder contains generated project reference documentation for the sanitized public mirror.

- [Architecture](Architecture.md)
- [Data Model](DataModel.md)
- [Flows](Flows.md)
- [Power Pages](PowerPages.md)
- [Business Central Integration](BCIntegration.md)
- [Decisions](Decisions.md)
- [Roadmap](Roadmap.md)
