# Business Central Integration

## Integration principle

BC is the system of record for customer, pricing, tax, totals, and sales order creation. Dataverse provides portal-optimized read/write structures for catalogue browsing and cart UX.

## BC-facing data held in Dataverse

- `Contact.ldw_bccustomerno` stores the BC customer number for a portal contact.
- `Catalog Item` stores BC item identifiers and portal display fields.
- `Public Price` and `Public Price Tier` store public/cache pricing derived from BC.
- `Cart Line 2` stores BC item references required for checkout.

## Customer resolution

```text
Contact has BC Customer No
  -> use existing BC customer

Contact has no BC Customer No
  -> create BC customer
  -> write BC Customer No back to Contact
  -> continue checkout
```

## Pricing rule

- Anonymous/public pricing can be displayed from Dataverse cache tables.
- Authenticated or checkout pricing should be calculated/finalized by BC.
- Portal-calculated subtotals are UX hints, not final accounting values.

## Order creation

Checkout should submit cart identity and line item references, not try to reproduce the BC pricing engine inside Power Pages. The integration layer should create the BC Sales Order and return the BC order number to Dataverse/portal.

## Sanitization note

Operational URLs, tenant identifiers, company identifiers, connection references, and environment-variable definitions are intentionally excluded or redacted from the public mirror.
