# Architecture

## Purpose

UNITEDBC is a B2B Power Pages storefront integrated with Dataverse and Business Central (BC). The portal provides catalogue browsing, server-side cart storage, checkout orchestration, and BC sales-order creation.

## Current architecture

The current architecture is Dataverse-first for the web experience and BC-authoritative for customer, pricing, and order outcomes.

```text
Power Pages
  -> Dataverse native tables
      - Catalog Item
      - Public Price / Public Price Tier
      - Cart / Cart Line 2
      - Checkout Request
  -> Power Automate integration layer
  -> Business Central APIs / custom BC logic
```

## Key architectural decisions

- Cart state is stored in Dataverse, not as draft orders in BC.
- Power Pages should not depend on BC virtual tables for storefront reads.
- Native Dataverse mirror/cache tables are used for catalogue and public pricing.
- BC remains authoritative for pricing, tax, totals, customer creation, and sales orders.
- Checkout is orchestrated outside the portal UI using Power Automate and BC integration endpoints.
- The source-controlled Power Platform solution is the private source of truth; this public mirror is a sanitized reference copy.

## Runtime flow

```text
Customer signs in
  -> Power Pages identifies Contact
  -> Portal gets or creates active Cart
  -> Customer adds Catalog Item to Cart Line 2
  -> Checkout creates Checkout Request or calls Checkout flow
  -> Flow resolves Contact -> BC Customer No
  -> Flow creates BC customer if needed
  -> Flow creates BC sales order and lines
  -> Cart is converted and stores BC order number/status
```

## Source-control model

```text
Private repository
  -> authoritative solution export
  -> includes operational configuration

Public mirror
  -> sanitized copy
  -> excludes connection references and environment variable definitions
  -> used for review, documentation, and AI-assisted project analysis
```
