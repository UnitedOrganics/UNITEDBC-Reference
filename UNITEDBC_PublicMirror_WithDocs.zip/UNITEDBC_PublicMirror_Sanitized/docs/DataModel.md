# Data Model

## Solution entities

| Display | Folder / logical | Entity set | Ownership | Columns |
| --- | --- | --- | --- | --- |
| contact | contact |  |  | 1 |
| BC Web Category Map | ldw_bcwebcategorymap | ldw_bcwebcategorymaps | UserOwned | 25 |
| Cart | ldw_cart | ldw_carts | UserOwned | 32 |
| Cart Line 2 | ldw_cartline2 | ldw_cartline2s | UserOwned | 28 |
| Catalog Item | ldw_catalogitem | ldw_catalogitems | OrgOwned | 51 |
| Checkout Request | ldw_checkoutrequest | ldw_checkoutrequests | UserOwned | 24 |
| Public Price | ldw_publicprice | ldw_publicprices | UserOwned | 26 |
| Public Price Tier | ldw_publicpricetier | ldw_publicpricetiers | UserOwned | 29 |
| Web Category | ldw_webcategory1 | ldw_webcategory1s | UserOwned | 18 |
| Web Department | ldw_webdepartment1 | ldw_webdepartment1s | UserOwned | 18 |

## Core business tables

### Catalog Item (`ldw_catalogitem`)

- Schema: `ldw_CatalogItem`
- Entity set: `ldw_catalogitems`
- Ownership: `OrgOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_alttext | Alt Text | nvarchar | none |
| ldw_bc_uom | BC UOM | nvarchar | none |
| ldw_bc_variantcode | BC Variant Code | nvarchar | none |
| ldw_bcitem_dvid | BC Item Dataverse Id | nvarchar | none |
| ldw_bcitemcategorycode | BC Item Category Code | nvarchar | none |
| ldw_bcitemid | BC Item Id | nvarchar | none |
| ldw_bcitemsystemid | BC Item System ID | nvarchar | none |
| ldw_bcproductgroupcode | BC Product Group Code | nvarchar | none |
| ldw_canonicalslug | Canonical Slug | nvarchar | none |
| ldw_catalogitemid | Catalog Item | primarykey | systemrequired |
| ldw_description | Description | ntext | none |
| ldw_imageurl | Image URL | nvarchar | none |
| ldw_inventory | Inventory | decimal | none |
| ldw_inventorypolicy | Inventory Policy | picklist | none |
| ldw_isvisible | Is Visible | bit | none |
| ldw_marketingcopy | Marketing Copy | ntext | none |
| ldw_metadescription | Meta Description | ntext | none |
| ldw_metatitle | Meta Title | nvarchar | none |
| ldw_name | Name | nvarchar | required |
| ldw_price | Price | money | none |
| ldw_price_base | Price (Base) | money | none |
| ldw_productnotes | Product Notes | ntext | none |
| ldw_seoheading | SEO Heading | nvarchar | none |
| ldw_sku | SKU | nvarchar | none |
| ldw_slug | Slug | nvarchar | none |
| ldw_status | Status | picklist | none |
| ldw_storagenotes | Storage Notes | ntext | none |
| ldw_taxgroupcode | BC Tax Group Code | nvarchar | none |
| ldw_thumbnailurl | Thumbnail URL | nvarchar | none |
| ldw_tierqty1 | Tier Qty 1 | int | none |
| ldw_tierqty2 | Tier Qty 2 | int | none |
| ldw_tierqty3 | Tier Qty 3 | int | none |
| ldw_webcategory | Web Category | lookup | none |
| ldw_webclassificationlocked | Web Classification Locked | bit | none |
| ldw_webdepartment | Web Department | lookup | none |
| ldw_websortorder | Web Sort Order | int | none |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |
| transactioncurrencyid | Currency | lookup | none |

### Public Price (`ldw_publicprice`)

- Schema: `ldw_publicprice`
- Entity set: `ldw_publicprices`
- Ownership: `UserOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_bcitemno | BC Item No | nvarchar | required |
| ldw_currencycode | Currency Code | nvarchar | required |
| ldw_lastsyncutc | Last Sync Utc | datetime | none |
| ldw_pricelistcode | Pricelist Code | nvarchar | required |
| ldw_publicpriceid | Public Price | primarykey | systemrequired |
| ldw_unitprice | Unit price | money | required |
| ldw_unitprice_base | Unit price (Base) | money | none |
| ldw_uom | UOM | nvarchar | none |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |
| transactioncurrencyid | Currency | lookup | none |

### Public Price Tier (`ldw_publicpricetier`)

- Schema: `ldw_publicpricetier`
- Entity set: `ldw_publicpricetiers`
- Ownership: `UserOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_bc_itemno | BCItemNo | nvarchar | required |
| ldw_currencycode | Currency Code | nvarchar | none |
| ldw_isactive | Is Active | bit | none |
| ldw_lastsyncutc | Last Sync UTC | nvarchar | none |
| ldw_minqty | Min Qty | int | none |
| ldw_priceincludingvat | Vat | bit | none |
| ldw_pricelistcode | Price list Code | nvarchar | none |
| ldw_publicpricetierid | Public Price Tier | primarykey | systemrequired |
| ldw_unitprice | Unit Price | money | none |
| ldw_unitprice_base | Unit Price (Base) | money | none |
| ldw_uom | UOM | nvarchar | none |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |
| transactioncurrencyid | Currency | lookup | none |

### Cart (`ldw_cart`)

- Schema: `ldw_Cart`
- Entity set: `ldw_carts`
- Ownership: `UserOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_cartid | Cart | primarykey | systemrequired |
| ldw_contact | Contact | lookup | required |
| ldw_externalorderno | External Order No | nvarchar | none |
| ldw_grandtotal | Grand Total | money | none |
| ldw_grandtotal_base | Grand Total (Base) | money | none |
| ldw_name | Name | nvarchar | required |
| ldw_pricelist | Price List | lookup | none |
| ldw_shipping | Shipping | money | none |
| ldw_shipping_base | Shipping (Base) | money | none |
| ldw_status | Status | picklist | none |
| ldw_subtotal | Subtotal | money | none |
| ldw_subtotal_base | Subtotal (Base) | money | none |
| ldw_tax | Tax | money | none |
| ldw_tax_base | Tax (Base) | money | none |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |
| transactioncurrencyid | Currency | lookup | none |

### Cart Line 2 (`ldw_cartline2`)

- Schema: `ldw_CartLine2`
- Entity set: `ldw_cartline2s`
- Ownership: `UserOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_bcitemdvid | BC Item DVID | nvarchar | none |
| ldw_bcitemid | BC Item Id | nvarchar | none |
| ldw_bcitemsystemid | BC Item System ID | nvarchar | none |
| ldw_cart | Cart | lookup | required |
| ldw_cartline2id | Cart Line 2 | primarykey | systemrequired |
| ldw_line | Line | nvarchar | required |
| ldw_lineamount | Line Amount | decimal | none |
| ldw_quantity | Quantity | decimal | none |
| ldw_unitprice | Unit Price | money | none |
| ldw_unitprice_base | Unit Price (Base) | money | none |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |
| transactioncurrencyid | Currency | lookup | none |

### Checkout Request (`ldw_checkoutrequest`)

- Schema: `ldw_CheckoutRequest`
- Entity set: `ldw_checkoutrequests`
- Ownership: `UserOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_cart | Cart | lookup | required |
| ldw_cartidtext | Cart ID Text | nvarchar | none |
| ldw_checkoutrequestid | Checkout Request | primarykey | systemrequired |
| ldw_error | Error | nvarchar | none |
| ldw_name | Name | nvarchar | required |
| ldw_note | Note | nvarchar | none |
| ldw_orderno | Order No | nvarchar | none |
| ldw_status | Status | picklist | none |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |

### Web Department (`ldw_webdepartment1`)

- Schema: `ldw_WebDepartment1`
- Entity set: `ldw_webdepartment1s`
- Ownership: `UserOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_webdepartment1id | Web Department | primarykey | systemrequired |
| ldw_webdepartmentname | Web Department Name | nvarchar | required |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |

### Web Category (`ldw_webcategory1`)

- Schema: `ldw_WebCategory1`
- Entity set: `ldw_webcategory1s`
- Ownership: `UserOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_webcategory1id | Web Category | primarykey | systemrequired |
| ldw_webcategoryname | Web Category Name | nvarchar | required |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |

### BC Web Category Map (`ldw_bcwebcategorymap`)

- Schema: `ldw_BCWebCategoryMap`
- Entity set: `ldw_bcwebcategorymaps`
- Ownership: `UserOwned`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_bcitemcategorycode | BC Item Category Code | nvarchar | none |
| ldw_bcproductgroupcode | BC Product Group Code | nvarchar | none |
| ldw_bcwebcategorymapid | BC Web Category Map | primarykey | systemrequired |
| ldw_defaultsortorder | Default Sort Order | int | none |
| ldw_defaultvisible | Default Visible | bit | none |
| ldw_isactive | Is Active | bit | none |
| ldw_name | Name | nvarchar | required |
| ldw_webcategory | Web Category | lookup | none |
| ldw_webdepartment | Web Department | lookup | none |
| statecode | Status | state | systemrequired |
| statuscode | Status Reason | status | none |

### contact (`contact`)

- Schema: `Contact`
- Entity set: `standard/external table`
- Ownership: `n/a`

| Column | Display | Type | Required |
| --- | --- | --- | --- |
| ldw_bccustomerno | BC Customer No | nvarchar | none |

## Important relationships

- `TransactionCurrency_ldw_Cart`
- `TransactionCurrency_ldw_CartLine2`
- `TransactionCurrency_ldw_CatalogItem`
- `TransactionCurrency_ldw_publicprice`
- `TransactionCurrency_ldw_publicpricetier`
- `business_unit_ldw_bcwebcategorymap`
- `business_unit_ldw_cart`
- `business_unit_ldw_cartline2`
- `business_unit_ldw_checkoutrequest`
- `business_unit_ldw_publicprice`
- `business_unit_ldw_publicpricetier`
- `business_unit_ldw_webcategory1`
- `business_unit_ldw_webdepartment1`
- `ldw_bcwebcategorymap_ldw_webcategory_ldw_webcategory1`
- `ldw_bcwebcategorymap_ldw_webdepartment_ldw_webdepartment1`
- `ldw_cart_PriceList_pricelevel`
- `ldw_cart_contact_contact`
- `ldw_cartline2_Cart_ldw_cart`
- `ldw_catalogitem_WebCategory_ldw_webcategory1`
- `ldw_catalogitem_WebDepartment_ldw_webdepartment1`
- `ldw_checkoutrequest_Cart_ldw_cart`
- `lk_ldw_bcwebcategorymap_createdby`
- `lk_ldw_bcwebcategorymap_modifiedby`
- `lk_ldw_cart_createdby`
- `lk_ldw_cart_modifiedby`
- `lk_ldw_cartline2_createdby`
- `lk_ldw_cartline2_modifiedby`
- `lk_ldw_catalogitem_createdby`
- `lk_ldw_catalogitem_modifiedby`
- `lk_ldw_checkoutrequest_createdby`
- `lk_ldw_checkoutrequest_modifiedby`
- `lk_ldw_publicprice_createdby`
- `lk_ldw_publicprice_modifiedby`
- `lk_ldw_publicpricetier_createdby`
- `lk_ldw_publicpricetier_modifiedby`
- `lk_ldw_webcategory1_createdby`
- `lk_ldw_webcategory1_modifiedby`
- `lk_ldw_webdepartment1_createdby`
- `lk_ldw_webdepartment1_modifiedby`
- `organization_ldw_catalogitem`
- `owner_ldw_bcwebcategorymap`
- `owner_ldw_cart`
- `owner_ldw_cartline2`
- `owner_ldw_checkoutrequest`
- `owner_ldw_publicprice`
- `owner_ldw_publicpricetier`
- `owner_ldw_webcategory1`
- `owner_ldw_webdepartment1`
- `team_ldw_bcwebcategorymap`
- `team_ldw_cart`
- `team_ldw_cartline2`
- `team_ldw_checkoutrequest`
- `team_ldw_publicprice`
- `team_ldw_publicpricetier`
- `team_ldw_webcategory1`
- `team_ldw_webdepartment1`
- `user_ldw_bcwebcategorymap`
- `user_ldw_cart`
- `user_ldw_cartline2`
- `user_ldw_checkoutrequest`
- `user_ldw_publicprice`
- `user_ldw_publicpricetier`
- `user_ldw_webcategory1`
- `user_ldw_webdepartment1`
